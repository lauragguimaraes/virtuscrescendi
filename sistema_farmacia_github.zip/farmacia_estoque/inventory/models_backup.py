# Backup dos modelos antes da implementação de multi-unidades
# Data: 26/08/2025

# Este arquivo contém os modelos originais antes da modificação para multi-unidades
# Pode ser usado para reverter se necessário

